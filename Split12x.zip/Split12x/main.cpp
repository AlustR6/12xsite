#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <chrono>
#include <map>
#include <limits>
#include <cmath>
#include <algorithm>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

using namespace std;
using namespace std::chrono;

// --- UI Color Theme ---
#define ACCENT_COLOR RGB(55, 62, 78)
#define BG_COLOR RGB(30, 32, 40)
#define FG_COLOR RGB(232, 232, 242)
#define FG_SUBTLE RGB(140, 148, 162)
#define TAB_BG_ACTIVE RGB(24, 26, 32)
#define TAB_BG_INACTIVE RGB(20, 21, 27)
#define TAB_BORDER_COLOR ACCENT_COLOR
#define TAB_BORDER_WIDTH 2
#define TAB_TEXT_COLOR FG_COLOR

#define BTN_BG RGB(47, 51, 65)
#define BTN_BG_HOVER RGB(61, 70, 102)
#define BTN_TEXT FG_COLOR
#define BORDER_ACCENT ACCENT_COLOR
#define OVERLAY_MODE_COLOR RGB(84, 180, 255)
#define INTERACTIVE_MODE_COLOR RGB(255, 220, 100)

#define CURRENT_SPLIT_BG RGB(40, 140, 80)
#define CURRENT_SPLIT_BORDER RGB(33, 100, 58)

#define SPLIT_PURPLE RGB(177, 85, 255)
#define SPLIT_GREEN RGB(180,255,180)
#define SPLIT_YELLOW RGB(255,255,120)

#define HOTKEY_TOGGLE_MODE 1
#define HOTKEY_SPLIT 2
#define HOTKEY_RESET 3
#define HOTKEY_CANCEL 4

#define CLOSE_BUTTON_SIZE 24
#define CLOSE_BUTTON_PADDING 10

#define TAB_WIDTH 95
#define TAB_HEIGHT 34
#define EDITBOX_WIDTH 180
#define EDITBOX_HEIGHT 28
#define EDITBOX_X 14 // unused, replaced for centering
#define EDITBOX_GAP 8
#define EDITBOX_SCROLL_AREA_HEIGHT 140

#define WINDOW_WIDTH 320
#define BASE_WINDOW_HEIGHT 220
#define MIN_WINDOW_HEIGHT 270
#define MAX_WINDOW_HEIGHT 900

#define TIMER_FONT_POINTSIZE 48
#define TAB_FONT_HEIGHT -18
#define SPLIT_FONT_HEIGHT -18
#define SPLIT_LINE_GAP 25
#define PB_PAD 10
#define SPLIT_BOTTOM_PAD 28

#define BTN_SPACING 8
#define BTN_WIDTH 180
#define BTN_HEIGHT 34

#define SCROLLBAR_WIDTH 12

enum Tabs { TAB_TIMER, TAB_KEYBINDS, TAB_EDIT_SPLITS };
int activeTab = TAB_TIMER;

bool clickThroughEnabled = true;
bool dragging = false;
POINT dragOffset;
HWND g_hwnd = nullptr;
RECT g_clientRect = {0,0,WINDOW_WIDTH,BASE_WINDOW_HEIGHT};

bool timerRunning = false;
bool timerStarted = false;
steady_clock::time_point startTime;
int currentSplit = 0;

vector<wstring> splitNames;
vector<duration<double>> splitSplitTimes;
vector<duration<double>> splitSplitAccum;
vector<duration<double>> bestSplitTimes;
vector<double> splitLastDelta;

duration<double> pbTotal = duration<double>::max();
duration<double> lastTotal = duration<double>(0);
double lastPBDelta = 0.0;
bool lastRunSetNewPB = false;
double lastRunOldPB = 0;

int selectedSplitIndex = -1;
vector<HWND> splitEditBoxes;
int editSplitsScrollPos = 0;
bool splitEditScrollDragging = false;
int splitEditScrollDragStartY = 0;
int splitEditScrollDragStartPos = 0;

std::map<std::string, int> keybinds = {
    {"toggle", '7'},
    {"split", VK_SPACE},
    {"cancel", 'C'}
};
std::map<std::string, int> pendingKeybinds = keybinds;
std::string rebinding = "";

HFONT CreateTimerFont(HWND hwnd) {
    HDC hdc = GetDC(hwnd);
    LOGFONTW lf = {0};
    lf.lfHeight = -MulDiv(TIMER_FONT_POINTSIZE, GetDeviceCaps(hdc, LOGPIXELSY), 72);
    lf.lfWeight = FW_NORMAL;
    lf.lfCharSet = DEFAULT_CHARSET;
    lf.lfOutPrecision = OUT_TT_PRECIS;
    lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
    lf.lfQuality = CLEARTYPE_QUALITY;
    lf.lfPitchAndFamily = VARIABLE_PITCH | FF_SWISS;
    wcsncpy(lf.lfFaceName, L"Segoe UI", LF_FACESIZE - 1);
    lf.lfFaceName[LF_FACESIZE - 1] = L'\0';
    ReleaseDC(hwnd, hdc);
    return CreateFontIndirectW(&lf);
}

void SyncBestSplits() {
    while (bestSplitTimes.size() < splitNames.size())
        bestSplitTimes.push_back(duration<double>::max());
    while (bestSplitTimes.size() > splitNames.size())
        bestSplitTimes.pop_back();
}
void SaveSplitsToFile(const string& filename) {
    ofstream file(filename);
    for (const auto& name : splitNames) {
        string s(name.begin(), name.end());
        file << s << endl;
    }
}
void LoadSplitsFromFile(const string& filename) {
    splitNames.clear();
    ifstream file(filename);
    string line;
    while (getline(file, line)) {
        wstring ws(line.begin(), line.end());
        if (!ws.empty()) splitNames.push_back(ws);
    }
    if (splitNames.empty()) splitNames = {L"Enter", L"Boss Start", L"idk", L"New Split", L"New Split"};
    SyncBestSplits();
}
void SaveBestSplitsToFile(const string& filename) {
    ofstream file(filename);
    for (auto t : bestSplitTimes)
        file << (t == duration<double>::max() ? -1.0 : t.count()) << endl;
}
void LoadBestSplitsFromFile(const string& filename) {
    bestSplitTimes.clear();
    ifstream file(filename);
    string line;
    while (getline(file, line)) {
        double val = stod(line);
        if (val < 0)
            bestSplitTimes.push_back(duration<double>::max());
        else
            bestSplitTimes.emplace_back(val);
    }
    SyncBestSplits();
}
void SaveKeybinds() {
    ofstream out("keybinds.cfg");
    for (auto& pair : keybinds) {
        out << pair.first << "=" << pair.second << endl;
    }
}
void LoadKeybinds() {
    ifstream in("keybinds.cfg");
    string line;
    while (getline(in, line)) {
        istringstream iss(line);
        string name;
        int code;
        if (getline(iss, name, '=') && iss >> code) {
            keybinds[name] = code;
            pendingKeybinds[name] = code;
        }
    }
}
void SavePBToFile(const string& filename) {
    ofstream f(filename);
    f << (pbTotal == duration<double>::max() ? -1.0 : pbTotal.count()) << endl;
}
void LoadPBFromFile(const string& filename) {
    pbTotal = duration<double>::max();
    ifstream f(filename);
    string line;
    if (getline(f, line)) {
        double val = stod(line);
        if (val >= 0) pbTotal = duration<double>(val);
    }
}
void ResetPB() {
    pbTotal = duration<double>::max();
    SavePBToFile("pbtime.txt");
}
void ResetBestSplitsAndPB() {
    for (auto& t : bestSplitTimes) t = duration<double>::max();
    SaveBestSplitsToFile("bestsplits.txt");
    ResetPB();
}
wstring FormatTime(duration<double> t) {
    if (t == duration<double>::max())
        return L"--:--.---";
    int total_ms = static_cast<int>(t.count() * 1000);
    int minutes = total_ms / 60000;
    int seconds = (total_ms / 1000) % 60;
    int ms = total_ms % 1000;
    wchar_t buffer[32];
    swprintf(buffer, 32, L"%02d:%02d.%03d", minutes, seconds, ms);
    return wstring(buffer);
}
wstring FormatDelta(double delta) {
    wchar_t buf[32];
    if (fabs(delta) < 1e-9) {
        swprintf(buf, 32, L" +0.00");
    } else if (delta > 0.0) {
        swprintf(buf, 32, L" +%.2f", delta);
    } else {
        swprintf(buf, 32, L" %.2f", delta);
    }
    return buf;
}
void SetClickThrough(bool enabled) {
    LONG_PTR exStyle = GetWindowLongPtrW(g_hwnd, GWL_EXSTYLE);
    if (enabled) {
        SetWindowLongPtrW(g_hwnd, GWL_EXSTYLE, exStyle | WS_EX_TRANSPARENT);
    } else {
        SetWindowLongPtrW(g_hwnd, GWL_EXSTYLE, exStyle & ~WS_EX_TRANSPARENT);
    }
    InvalidateRect(g_hwnd, NULL, TRUE);
}
void RegisterKeybinds() {
    UnregisterHotKey(g_hwnd, HOTKEY_TOGGLE_MODE);
    UnregisterHotKey(g_hwnd, HOTKEY_SPLIT);
    UnregisterHotKey(g_hwnd, HOTKEY_RESET);
    UnregisterHotKey(g_hwnd, HOTKEY_CANCEL);
    RegisterHotKey(g_hwnd, HOTKEY_TOGGLE_MODE, 0, keybinds["toggle"]);
    RegisterHotKey(g_hwnd, HOTKEY_SPLIT, 0, keybinds["split"]);
    RegisterHotKey(g_hwnd, HOTKEY_CANCEL, 0, keybinds["cancel"]);
}
bool IsInsideRect(int x, int y, RECT r) {
    return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
}
RECT GetTabRect(int index) {
    return { index * TAB_WIDTH, 0, (index + 1) * TAB_WIDTH, TAB_HEIGHT };
}
RECT GetButtonRect(int x, int y, int w, int h) {
    return { x, y, x + w, y + h };
}
RECT GetCenteredButtonRect(int idx, int numButtons, int btnWidth = BTN_WIDTH, int btnHeight = BTN_HEIGHT, int spacing = BTN_SPACING) {
    int totalHeight = numButtons * btnHeight + (numButtons - 1) * spacing;
    int startY = TAB_HEIGHT + 42;
    startY += ((BASE_WINDOW_HEIGHT - TAB_HEIGHT - totalHeight) / 3);
    int x = (WINDOW_WIDTH - btnWidth) / 2;
    int y = startY + idx * (btnHeight + spacing);
    return GetButtonRect(x, y, btnWidth, btnHeight);
}
int GetEditSplitsScrollStartY() {
    int numButtons = 3;
    RECT lastBtn = GetCenteredButtonRect(numButtons - 1, numButtons);
    return lastBtn.bottom + 16;
}

// -- Centering and Themed EditBoxes --
RECT GetCenteredEditBoxRect(int idx, int totalSplits, int scrollPos) {
    int areaY = GetEditSplitsScrollStartY();
    int areaH = EDITBOX_SCROLL_AREA_HEIGHT;
    int boxY = areaY + idx * (EDITBOX_HEIGHT + EDITBOX_GAP) - scrollPos;
    int boxX = (WINDOW_WIDTH - EDITBOX_WIDTH) / 2;
    return GetButtonRect(boxX, boxY, EDITBOX_WIDTH, EDITBOX_HEIGHT);
}

void UpdateSplitEditBoxes() {
    for (HWND h : splitEditBoxes) {
        if (IsWindow(h)) DestroyWindow(h);
    }
    splitEditBoxes.clear();
    if (activeTab == TAB_EDIT_SPLITS && !clickThroughEnabled) {
        for (int i = 0; i < splitNames.size(); ++i) {
            RECT r = GetCenteredEditBoxRect(i, (int)splitNames.size(), editSplitsScrollPos);
            int yStart = GetEditSplitsScrollStartY();
            if (r.bottom < yStart || r.top > yStart + EDITBOX_SCROLL_AREA_HEIGHT) continue;
            HWND hEdit = CreateWindowW(
                L"EDIT", splitNames[i].c_str(),
                WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
                r.left, r.top, EDITBOX_WIDTH, EDITBOX_HEIGHT,
                g_hwnd, (HMENU)(INT_PTR)(1000 + i), NULL, NULL);
            HFONT hFont = CreateFontW(-15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                      DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
                                      CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Segoe UI");
            SendMessageW(hEdit, WM_SETFONT, (WPARAM)hFont, TRUE);
            splitEditBoxes.push_back(hEdit);
        }
    }
}

// -- Custom themed EditBox painting --
LRESULT CALLBACK EditSubclassProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam,
                                 UINT_PTR, DWORD_PTR) {
    switch (msg) {
        case WM_NCPAINT: {
            HDC hdc = GetWindowDC(hwnd);
            RECT r;
            GetWindowRect(hwnd, &r);
            OffsetRect(&r, -r.left, -r.top);
            HPEN pen = CreatePen(PS_SOLID, 2, ACCENT_COLOR);
            HGDIOBJ oldPen = SelectObject(hdc, pen);
            HBRUSH bg = CreateSolidBrush(BTN_BG);
            FillRect(hdc, &r, bg);
            DeleteObject(bg);
            Rectangle(hdc, 0, 0, r.right, r.bottom);
            SelectObject(hdc, oldPen);
            DeleteObject(pen);
            ReleaseDC(hwnd, hdc);
            return 0;
        }
        case WM_CTLCOLOREDIT: {
            HDC hdc = (HDC)wParam;
            SetTextColor(hdc, FG_COLOR);
            SetBkColor(hdc, BTN_BG);
            HBRUSH bgBrush = CreateSolidBrush(BTN_BG);
            return (INT_PTR)bgBrush;
        }
        case WM_DESTROY:
            RemoveWindowSubclass(hwnd, EditSubclassProc, 0);
            break;
    }
    return DefSubclassProc(hwnd, msg, wParam, lParam);
}

void ApplySplitNameEdits() {
    wchar_t buffer[256];
    for (size_t i = 0; i < splitEditBoxes.size(); ++i) {
        if (IsWindow(splitEditBoxes[i])) {
            GetWindowTextW(splitEditBoxes[i], buffer, 256);
            int idx = i;
            if (idx >= 0 && idx < (int)splitNames.size())
                splitNames[idx] = buffer;
        }
    }
    SyncBestSplits();
}
void AdjustWindowHeightForSplits(HWND hwnd) {
    int numSplits = splitNames.size();
    int splitLines = max(1, numSplits);
    int base = BASE_WINDOW_HEIGHT;
    int splitHeight = SPLIT_LINE_GAP * splitLines;
    int totalHeight = base + splitHeight + SPLIT_BOTTOM_PAD;
    int minH = MIN_WINDOW_HEIGHT;
    int maxH = MAX_WINDOW_HEIGHT;
    int finalHeight = min(maxH, max(minH, totalHeight));
    RECT r;
    GetWindowRect(hwnd, &r);
    SetWindowPos(hwnd, NULL, r.left, r.top, WINDOW_WIDTH, finalHeight, SWP_NOZORDER | SWP_NOACTIVATE);
    g_clientRect.bottom = finalHeight;
}
void UpdateBestSplitsAndStoreDeltasAndPB() {
    SyncBestSplits();
    splitLastDelta.clear();
    lastRunSetNewPB = false;
    lastTotal = splitSplitAccum.empty() ? duration<double>(0) : splitSplitAccum.back();

    double prevPB = pbTotal.count();
    if (pbTotal == duration<double>::max()) prevPB = 0.0;
    lastRunOldPB = prevPB;
    lastPBDelta = lastTotal.count() - prevPB;

    if (lastTotal != duration<double>::max() && lastTotal.count() > 0 && (pbTotal == duration<double>::max() || lastTotal < pbTotal)) {
        pbTotal = lastTotal;
        SavePBToFile("pbtime.txt");
        lastRunSetNewPB = true;
    }

    for (size_t i = 0; i < splitSplitTimes.size(); ++i) {
        double delta = splitSplitTimes[i].count() - (i < bestSplitTimes.size() && bestSplitTimes[i] != duration<double>::max() ? bestSplitTimes[i].count() : 0.0);
        splitLastDelta.push_back(delta);
        if (splitSplitTimes[i] < bestSplitTimes[i])
            bestSplitTimes[i] = splitSplitTimes[i];
    }
    while (splitLastDelta.size() < splitNames.size())
        splitLastDelta.push_back(0.0);
    SaveBestSplitsToFile("bestsplits.txt");
}
wstring GetDeltaString(int splitIdx, bool recap = false) {
    wchar_t cmpBuf[32];
    double delta = 0;
    bool hasDelta = false;
    if (recap) {
        if (splitIdx < (int)splitLastDelta.size()) {
            delta = splitLastDelta[splitIdx];
            hasDelta = true;
        }
    } else {
        if (splitIdx < (int)splitSplitTimes.size() &&
            splitIdx < (int)bestSplitTimes.size() &&
            bestSplitTimes[splitIdx] != duration<double>::max()) {
            delta = splitSplitTimes[splitIdx].count() - bestSplitTimes[splitIdx].count();
            hasDelta = true;
        }
    }
    if (!hasDelta)
        return L"";
    if (fabs(delta) < 1e-9) {
        swprintf(cmpBuf, 32, L" +0.00");
    } else if (delta > 0.0) {
        swprintf(cmpBuf, 32, L" +%.2f", delta);
    } else {
        swprintf(cmpBuf, 32, L" %.2f", delta);
    }
    return cmpBuf;
}
COLORREF GetDeltaColor(double delta) {
    if (delta < -3.0) return SPLIT_PURPLE;
    if (delta < 0.0) return SPLIT_GREEN;
    if (delta > 0.0) return SPLIT_YELLOW;
    return RGB(240, 255, 160);
}
void EnsureTopMost(HWND hwnd) {
    SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
        SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
}
void DrawRectWithBorder(HDC hdc, RECT r, COLORREF fill, COLORREF border, int borderWidth = 2) {
    int r1 = GetRValue(fill), g1 = GetGValue(fill), b1 = GetBValue(fill);
    int r2 = GetRValue(BG_COLOR), g2 = GetGValue(BG_COLOR), b2 = GetBValue(BG_COLOR);
    int blendpct = 70;
    COLORREF blended = RGB((r1*blendpct + r2*(100-blendpct))/100, (g1*blendpct + g2*(100-blendpct))/100, (b1*blendpct + b2*(100-blendpct))/100);

    HBRUSH b = CreateSolidBrush(blended);
    FillRect(hdc, &r, b);
    DeleteObject(b);
    HPEN pen = CreatePen(PS_SOLID, borderWidth, border);
    HPEN old = (HPEN)SelectObject(hdc, pen);
    MoveToEx(hdc, r.left, r.top, NULL);
    LineTo(hdc, r.right-1, r.top);
    LineTo(hdc, r.right-1, r.bottom-1);
    LineTo(hdc, r.left, r.bottom-1);
    LineTo(hdc, r.left, r.top);
    SelectObject(hdc, old);
    DeleteObject(pen);
}
void DrawRoundRectWithBorder(HDC hdc, RECT r, COLORREF fill, COLORREF border, int radius = 8, int borderWidth = 2) {
    HBRUSH b = CreateSolidBrush(fill);
    FillRect(hdc, &r, b);
    DeleteObject(b);
    HPEN pen = CreatePen(PS_SOLID, borderWidth, border);
    HPEN old = (HPEN)SelectObject(hdc, pen);
    HBRUSH nullBrush = (HBRUSH)GetStockObject(NULL_BRUSH);
    HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, nullBrush);
    RoundRect(hdc, r.left, r.top, r.right, r.bottom, radius, radius);
    SelectObject(hdc, oldBrush);
    SelectObject(hdc, old);
    DeleteObject(pen);
}
void DrawScrollBar(HDC hdc, RECT area, int totalHeight, int scrollPos, int visibleHeight) {
    HBRUSH bgBrush = CreateSolidBrush(RGB(50, 55, 70));
    FillRect(hdc, &area, bgBrush);
    DeleteObject(bgBrush);

    int scrollRange = max(0, totalHeight - visibleHeight);
    int areaHeight = area.bottom - area.top;
    int thumbHeight = std::max(25, int((double(visibleHeight) * areaHeight) / std::max(double(visibleHeight), double(totalHeight))));
    int thumbY = area.top;
    if (scrollRange > 0)
        thumbY += ((areaHeight - thumbHeight) * scrollPos) / scrollRange;

    RECT thumb = { area.left + 2, thumbY, area.right - 2, thumbY + thumbHeight };
    HBRUSH thumbBrush = CreateSolidBrush(RGB(90, 120, 170));
    FillRect(hdc, &thumb, thumbBrush);
    DeleteObject(thumbBrush);
}
void DrawTabBar(HDC hdc) {
    HFONT tabFont = CreateFontW(TAB_FONT_HEIGHT, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
                                CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Segoe UI");
    HFONT oldTabFont = (HFONT)SelectObject(hdc, tabFont);
    SetBkMode(hdc, TRANSPARENT);
    for (int i = 0; i < 3; ++i) {
        RECT r = GetTabRect(i);
        HBRUSH bTab = CreateSolidBrush(i == activeTab ? TAB_BG_ACTIVE : TAB_BG_INACTIVE);
        FillRect(hdc, &r, bTab);
        DeleteObject(bTab);

        HPEN pen = CreatePen(PS_SOLID, TAB_BORDER_WIDTH, TAB_BORDER_COLOR);
        HPEN oldPen = (HPEN)SelectObject(hdc, pen);
        MoveToEx(hdc, r.left, r.top, NULL);
        LineTo(hdc, r.right, r.top);
        LineTo(hdc, r.right, r.bottom-1);
        LineTo(hdc, r.left, r.bottom-1);
        LineTo(hdc, r.left, r.top);
        SelectObject(hdc, oldPen);
        DeleteObject(pen);

        const wchar_t* label = (i == 0) ? L"Timer" : (i == 1) ? L"Keybinds" : L"Edit Splits";
        SetTextColor(hdc, TAB_TEXT_COLOR);
        DrawTextW(hdc, label, -1, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    }
    SelectObject(hdc, oldTabFont);
    DeleteObject(tabFont);
}
void DrawCloseButton(HDC hdc, RECT r, bool hovered) {
    int diameter = min(r.right - r.left, r.bottom - r.top);
    int cx = (r.left + r.right) / 2;
    int cy = (r.top + r.bottom) / 2;
    int rad = diameter / 2 - 1;
    COLORREF bg = hovered ? RGB(239,71,111) : RGB(24, 26, 32);
    COLORREF xColor = hovered ? RGB(255,255,255) : RGB(0,0,0);

    HBRUSH bgBrush = CreateSolidBrush(bg);
    HPEN borderPen = CreatePen(PS_SOLID, 2, bg);
    HGDIOBJ oldBrush = SelectObject(hdc, bgBrush);
    HGDIOBJ oldPen = SelectObject(hdc, borderPen);
    Ellipse(hdc, cx - rad, cy - rad, cx + rad, cy + rad);
    SelectObject(hdc, oldBrush);
    SelectObject(hdc, oldPen);
    DeleteObject(bgBrush);
    DeleteObject(borderPen);

    HPEN xPen = CreatePen(PS_SOLID, 2, xColor);
    oldPen = SelectObject(hdc, xPen);
    double pad = diameter * 0.33;
    POINT line1[2] = {
        { (int)(cx - pad + 0.5), (int)(cy - pad + 0.5) },
        { (int)(cx + pad + 0.5), (int)(cy + pad + 0.5) }
    };
    POINT line2[2] = {
        { (int)(cx - pad + 0.5), (int)(cy + pad + 0.5) },
        { (int)(cx + pad + 0.5), (int)(cy - pad + 0.5) }
    };
    Polyline(hdc, line1, 2);
    Polyline(hdc, line2, 2);
    SelectObject(hdc, oldPen);
    DeleteObject(xPen);
}
wstring GetKeyName(int vk) {
    UINT scan = MapVirtualKey(vk, MAPVK_VK_TO_VSC) << 16;
    wchar_t name[128];
    if (GetKeyNameTextW(scan, name, 128) > 0) {
        return name;
    }
    wchar_t buf[16];
    swprintf(buf, 16, L"VK_%02X", vk);
    return buf;
}
void CancelTimerAndSplits() {
    timerRunning = false;
    timerStarted = false;
    splitSplitTimes.clear();
    splitSplitAccum.clear();
    currentSplit = 0;
    splitLastDelta.clear();
}
LRESULT HandleWMGetDlgCode(HWND hwnd)
{
    HWND focus = GetFocus();
    if (focus && GetParent(focus) == hwnd) {
        wchar_t className[16];
        GetClassNameW(focus, className, 16);
        if (lstrcmpiW(className, L"Edit") == 0) {
            return 0;
        }
    }
    return DLGC_WANTALLKEYS;
}
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    static UINT timerID = 0;
    static bool closeHover = false;
    switch (uMsg) {
        case WM_CREATE:
            timerID = SetTimer(hwnd, 1, 15, NULL);
            break;
        case WM_TIMER:
            InvalidateRect(hwnd, NULL, FALSE);
            static int tick = 0;
            if (++tick % 66 == 0) EnsureTopMost(hwnd);
            break;
        case WM_SETCURSOR: {
            POINT pt;
            GetCursorPos(&pt);
            ScreenToClient(hwnd, &pt);
            RECT client;
            GetClientRect(hwnd, &client);
            RECT closeBtn = { client.right - CLOSE_BUTTON_SIZE - CLOSE_BUTTON_PADDING,
                              CLOSE_BUTTON_PADDING,
                              client.right - CLOSE_BUTTON_PADDING,
                              CLOSE_BUTTON_PADDING + CLOSE_BUTTON_SIZE };
            if (IsInsideRect(pt.x, pt.y, closeBtn)) {
                SetCursor(LoadCursor(NULL, IDC_HAND));
                return TRUE;
            }
            if (!clickThroughEnabled) {
                SetCursor(LoadCursor(NULL, IDC_ARROW));
                return TRUE;
            }
            break;
        }
        case WM_MOUSEMOVE: {
            POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
            RECT client;
            GetClientRect(hwnd, &client);
            RECT closeBtn = { client.right - CLOSE_BUTTON_SIZE - CLOSE_BUTTON_PADDING,
                              CLOSE_BUTTON_PADDING,
                              client.right - CLOSE_BUTTON_PADDING,
                              CLOSE_BUTTON_PADDING + CLOSE_BUTTON_SIZE };
            bool wasHover = closeHover;
            closeHover = IsInsideRect(pt.x, pt.y, closeBtn);
            if (closeHover != wasHover) InvalidateRect(hwnd, &closeBtn, FALSE);

            if (splitEditScrollDragging && activeTab == TAB_EDIT_SPLITS && !clickThroughEnabled) {
                int totalHeight = (int)splitNames.size() * (EDITBOX_HEIGHT + EDITBOX_GAP);
                int pageHeight = EDITBOX_SCROLL_AREA_HEIGHT;
                int scrollRange = max(0, totalHeight - pageHeight);
                RECT scrollBarArea = { (WINDOW_WIDTH - EDITBOX_WIDTH) / 2 + EDITBOX_WIDTH + 8,
                                       GetEditSplitsScrollStartY(),
                                       (WINDOW_WIDTH - EDITBOX_WIDTH) / 2 + EDITBOX_WIDTH + 8 + SCROLLBAR_WIDTH,
                                       GetEditSplitsScrollStartY() + EDITBOX_SCROLL_AREA_HEIGHT };
                int mouseY = pt.y;
                int thumbHeight = std::max(25, int((double(pageHeight) * (scrollBarArea.bottom - scrollBarArea.top)) / std::max(double(pageHeight), double(totalHeight))));
                int areaHeight = scrollBarArea.bottom - scrollBarArea.top;
                int thumbPos = splitEditScrollDragStartPos + (mouseY - splitEditScrollDragStartY) * scrollRange / std::max(1, areaHeight - thumbHeight);
                editSplitsScrollPos = max(0, min(scrollRange, thumbPos));
                UpdateSplitEditBoxes();
                InvalidateRect(hwnd, NULL, TRUE);
            }
            if (dragging && !clickThroughEnabled) {
                POINT p;
                GetCursorPos(&p);
                SetWindowPos(hwnd, NULL, p.x - dragOffset.x, p.y - dragOffset.y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
            }
            break;
        }
        case WM_LBUTTONDOWN: {
            int x = GET_X_LPARAM(lParam);
            int y = GET_Y_LPARAM(lParam);

            bool hitTab = false, hitBtn = false, hitClose = false;
            for (int i = 0; i < 3; ++i) {
                if (IsInsideRect(x, y, GetTabRect(i))) {
                    hitTab = true;
                    break;
                }
            }
            RECT client;
            GetClientRect(hwnd, &client);
            RECT closeBtn = { client.right - CLOSE_BUTTON_SIZE - CLOSE_BUTTON_PADDING,
                              CLOSE_BUTTON_PADDING,
                              client.right - CLOSE_BUTTON_PADDING,
                              CLOSE_BUTTON_PADDING + CLOSE_BUTTON_SIZE };
            if (IsInsideRect(x, y, closeBtn))
                hitClose = true;

            if (activeTab == TAB_EDIT_SPLITS && !clickThroughEnabled) {
                int totalHeight = (int)splitNames.size() * (EDITBOX_HEIGHT + EDITBOX_GAP);
                int pageHeight = EDITBOX_SCROLL_AREA_HEIGHT;
                RECT scrollBarArea = { (WINDOW_WIDTH - EDITBOX_WIDTH) / 2 + EDITBOX_WIDTH + 8,
                                       GetEditSplitsScrollStartY(),
                                       (WINDOW_WIDTH - EDITBOX_WIDTH) / 2 + EDITBOX_WIDTH + 8 + SCROLLBAR_WIDTH,
                                       GetEditSplitsScrollStartY() + EDITBOX_SCROLL_AREA_HEIGHT };
                if (IsInsideRect(x, y, scrollBarArea)) {
                    splitEditScrollDragging = true;
                    splitEditScrollDragStartY = y;
                    splitEditScrollDragStartPos = editSplitsScrollPos;
                    SetCapture(hwnd);
                    return 0;
                }
            }

            if (hitClose) {
                if (activeTab == TAB_EDIT_SPLITS) {
                    ApplySplitNameEdits();
                    SaveSplitsToFile("splits.txt");
                    SaveBestSplitsToFile("bestsplits.txt");
                }
                PostQuitMessage(0);
                return 0;
            }

            if (activeTab == TAB_KEYBINDS && !clickThroughEnabled) {
                int numButtons = 4;
                RECT toggleBtn = GetCenteredButtonRect(0, numButtons);
                RECT splitBtn = GetCenteredButtonRect(1, numButtons);
                RECT cancelBtn = GetCenteredButtonRect(2, numButtons);
                RECT saveBtn  = GetCenteredButtonRect(3, numButtons);
                if (IsInsideRect(x, y, toggleBtn))
                    { rebinding = "toggle"; InvalidateRect(hwnd, NULL, TRUE); return 0; }
                if (IsInsideRect(x, y, splitBtn))
                    { rebinding = "split"; InvalidateRect(hwnd, NULL, TRUE); return 0; }
                if (IsInsideRect(x, y, cancelBtn))
                    { rebinding = "cancel"; InvalidateRect(hwnd, NULL, TRUE); return 0; }
                if (IsInsideRect(x, y, saveBtn)) {
                    keybinds = pendingKeybinds;
                    SaveKeybinds();
                    RegisterKeybinds();
                    InvalidateRect(hwnd, NULL, TRUE);
                    return 0;
                }
            }

            if (activeTab == TAB_EDIT_SPLITS && !clickThroughEnabled) {
                int numButtons = 3;
                RECT addBtn = GetCenteredButtonRect(0, numButtons);
                RECT removeBtn = GetCenteredButtonRect(1, numButtons);
                RECT resetBestBtn = GetCenteredButtonRect(2, numButtons);
                if (IsInsideRect(x, y, addBtn)) {
                    ApplySplitNameEdits();
                    splitNames.push_back(L"New Split");
                    SyncBestSplits();
                    SaveSplitsToFile("splits.txt");
                    SaveBestSplitsToFile("bestsplits.txt");
                    UpdateSplitEditBoxes();
                    AdjustWindowHeightForSplits(hwnd);
                    InvalidateRect(hwnd, NULL, TRUE);
                    return 0;
                }
                if (IsInsideRect(x, y, removeBtn)) {
                    if (!splitNames.empty()) {
                        ApplySplitNameEdits();
                        splitNames.pop_back();
                        SyncBestSplits();
                        SaveSplitsToFile("splits.txt");
                        SaveBestSplitsToFile("bestsplits.txt");
                        UpdateSplitEditBoxes();
                        AdjustWindowHeightForSplits(hwnd);
                        if (selectedSplitIndex >= (int)splitNames.size()) selectedSplitIndex = -1;
                        InvalidateRect(hwnd, NULL, TRUE);
                        return 0;
                    }
                }
                if (IsInsideRect(x, y, resetBestBtn)) {
                    ResetBestSplitsAndPB();
                    InvalidateRect(hwnd, NULL, TRUE);
                    return 0;
                }
                int yStart = GetEditSplitsScrollStartY();
                for (int i = 0; i < (int)splitNames.size(); ++i) {
                    RECT nameBox = GetCenteredEditBoxRect(i, (int)splitNames.size(), editSplitsScrollPos);
                    if (IsInsideRect(x, y, nameBox)) {
                        selectedSplitIndex = i;
                        InvalidateRect(hwnd, NULL, TRUE);
                        return 0;
                    }
                }
            }

            if (!clickThroughEnabled && !hitTab && !hitBtn && !hitClose) {
                dragging = true;
                POINT p;
                GetCursorPos(&p);
                RECT win;
                GetWindowRect(hwnd, &win);
                dragOffset.x = p.x - win.left;
                dragOffset.y = p.y - win.top;
                SetCapture(hwnd);
                return 0;
            }
            for (int i = 0; i < 3; ++i) {
                if (IsInsideRect(x, y, GetTabRect(i))) {
                    if (activeTab == TAB_EDIT_SPLITS) {
                        ApplySplitNameEdits();
                        SaveSplitsToFile("splits.txt");
                        SaveBestSplitsToFile("bestsplits.txt");
                    }
                    activeTab = i;
                    editSplitsScrollPos = 0;
                    UpdateSplitEditBoxes();
                    AdjustWindowHeightForSplits(hwnd);
                    InvalidateRect(hwnd, NULL, TRUE);
                    return 0;
                }
            }
            break;
        }
        case WM_LBUTTONUP:
            if (dragging) {
                dragging = false;
                ReleaseCapture();
            }
            if (splitEditScrollDragging) {
                splitEditScrollDragging = false;
                ReleaseCapture();
            }
            break;
        case WM_MOUSEWHEEL:
            if (activeTab == TAB_EDIT_SPLITS) {
                int delta = GET_WHEEL_DELTA_WPARAM(wParam);
                int totalHeight = (int)splitNames.size() * (EDITBOX_HEIGHT + EDITBOX_GAP);
                int pageHeight = EDITBOX_SCROLL_AREA_HEIGHT;
                editSplitsScrollPos -= (EDITBOX_HEIGHT + EDITBOX_GAP) * ((delta > 0) ? 1 : -1);
                editSplitsScrollPos = max(0, min(editSplitsScrollPos, max(0, totalHeight - pageHeight)));
                UpdateSplitEditBoxes();
                InvalidateRect(hwnd, NULL, TRUE);
            }
            break;
        case WM_HOTKEY:
            if (rebinding.empty() && !(activeTab == TAB_EDIT_SPLITS && GetFocus() && GetParent(GetFocus()) == hwnd)) {
                if (wParam == HOTKEY_TOGGLE_MODE) {
                    clickThroughEnabled = !clickThroughEnabled;
                    SetClickThrough(clickThroughEnabled);
                } else if (wParam == HOTKEY_SPLIT) {
                    if (!timerRunning && currentSplit >= (int)splitNames.size()) {
                        CancelTimerAndSplits();
                        InvalidateRect(hwnd, NULL, TRUE);
                        break;
                    }
                    if (!timerRunning) {
                        timerRunning = true;
                        timerStarted = true;
                        startTime = steady_clock::now();
                        splitSplitTimes.clear();
                        splitSplitAccum.clear();
                        currentSplit = 0;
                        splitLastDelta.clear();
                    } else if (currentSplit < (int)splitNames.size()) {
                        steady_clock::time_point now = steady_clock::now();
                        duration<double> thisSplit = (currentSplit == 0)
                            ? (now - startTime)
                            : (now - startTime - splitSplitAccum.back());
                        splitSplitTimes.push_back(thisSplit);
                        if (splitSplitAccum.empty())
                            splitSplitAccum.push_back(thisSplit);
                        else
                            splitSplitAccum.push_back(splitSplitAccum.back() + thisSplit);
                        currentSplit++;
                        if (currentSplit >= (int)splitNames.size()) {
                            timerRunning = false;
                            UpdateBestSplitsAndStoreDeltasAndPB();
                        }
                    }
                    InvalidateRect(hwnd, NULL, TRUE);
                } else if (wParam == HOTKEY_CANCEL) {
                    CancelTimerAndSplits();
                    InvalidateRect(hwnd, NULL, TRUE);
                }
            }
            break;
        case WM_KEYDOWN:
            if (!rebinding.empty()) {
                pendingKeybinds[rebinding] = (int)wParam;
                rebinding = "";
                InvalidateRect(hwnd, NULL, TRUE);
            }
            break;
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hwnd, &ps);

            RECT client;
            GetClientRect(hwnd, &client);
            HDC memDC = CreateCompatibleDC(hdc);
            HBITMAP memBM = CreateCompatibleBitmap(hdc, client.right, client.bottom);
            HBITMAP oldBM = (HBITMAP)SelectObject(memDC, memBM);

            HBRUSH bg = CreateSolidBrush(BG_COLOR);
            FillRect(memDC, &client, bg);
            DeleteObject(bg);

            DrawTabBar(memDC);

            RECT closeBtn = { client.right - CLOSE_BUTTON_SIZE - CLOSE_BUTTON_PADDING,
                              CLOSE_BUTTON_PADDING,
                              client.right - CLOSE_BUTTON_PADDING,
                              CLOSE_BUTTON_PADDING + CLOSE_BUTTON_SIZE };
            DrawCloseButton(memDC, closeBtn, false);

            int winW = client.right - client.left;

            HFONT modeFont = CreateFontW(-18, 0, 0, 0, FW_MEDIUM, FALSE, FALSE, FALSE,
                                         DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
                                         CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Segoe UI");
            HFONT oldFont = (HFONT)SelectObject(memDC, modeFont);

            const wchar_t* modeText = clickThroughEnabled ? L"Mode: Overlay" : L"Mode: Interactive";
            COLORREF modeColor = clickThroughEnabled ? OVERLAY_MODE_COLOR : INTERACTIVE_MODE_COLOR;
            SIZE modeSz;
            GetTextExtentPoint32W(memDC, modeText, (int)wcslen(modeText), &modeSz);
            int modeX = (WINDOW_WIDTH - modeSz.cx) / 2;
            int modeY = TAB_HEIGHT + 4;
            SetTextColor(memDC, modeColor);
            TextOutW(memDC, modeX, modeY, modeText, (int)wcslen(modeText));
            SelectObject(memDC, oldFont);
            DeleteObject(modeFont);

            if (activeTab == TAB_TIMER) {
                HFONT timerFont = CreateTimerFont(hwnd);
                HFONT oldTimerFont = (HFONT)SelectObject(memDC, timerFont);

                duration<double> elapsed = duration<double>(0);
                if (timerStarted && timerRunning)
                    elapsed = steady_clock::now() - startTime;
                else if (!timerRunning && !splitSplitAccum.empty())
                    elapsed = splitSplitAccum.back();
                wstring timeStr = FormatTime(elapsed);
                SIZE sz;
                GetTextExtentPoint32W(memDC, timeStr.c_str(), (int)timeStr.length(), &sz);
                int timerX = (WINDOW_WIDTH - sz.cx) / 2;
                int timerY = modeY + modeSz.cy + 10;
                SetTextColor(memDC, FG_COLOR);
                TextOutW(memDC, timerX, timerY, timeStr.c_str(), (int)timeStr.length());
                SelectObject(memDC, oldTimerFont);
                DeleteObject(timerFont);

                HFONT pbFont = CreateFontW(-18, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
                                         DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
                                         CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Segoe UI");
                HFONT oldPbFont = (HFONT)SelectObject(memDC, pbFont);
                wstring pbLabel = L"PB: " + FormatTime(pbTotal);
                bool recap = (!timerRunning && !splitSplitTimes.empty() && splitLastDelta.size() == splitNames.size());
                bool showPBDelta = recap && pbTotal != duration<double>::max() && lastTotal != duration<double>::max() && lastTotal.count() > 0;
                double d = lastPBDelta;
                if (showPBDelta) {
                    if (fabs(d) >= 0.005)
                        pbLabel += FormatDelta(d);
                    else
                        pbLabel += L" +0.00";
                }
                SIZE pbSz;
                GetTextExtentPoint32W(memDC, pbLabel.c_str(), (int)pbLabel.length(), &pbSz);
                int pbX = (WINDOW_WIDTH - pbSz.cx) / 2;
                int pbY = timerY + sz.cy + PB_PAD;
                COLORREF pbDeltaColor = ACCENT_COLOR;
                if (showPBDelta) {
                    pbDeltaColor = GetDeltaColor(d);
                }
                SetTextColor(memDC, pbDeltaColor);
                TextOutW(memDC, pbX, pbY, pbLabel.c_str(), (int)pbLabel.length());
                SelectObject(memDC, oldPbFont);
                DeleteObject(pbFont);

                int barW = WINDOW_WIDTH - 40;
                int barH = 7;
                int barY = pbY + pbSz.cy + PB_PAD;
                int barX = (WINDOW_WIDTH - barW) / 2;
                RECT barRect = { barX, barY, barX + barW, barY + barH };
                DrawRoundRectWithBorder(memDC, barRect, ACCENT_COLOR, BORDER_ACCENT, 4, 2);

                HFONT splitFont = CreateFontW(SPLIT_FONT_HEIGHT, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                              DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
                                              CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Segoe UI");
                HFONT oldSplitFont = (HFONT)SelectObject(memDC, splitFont);
                int y = barRect.bottom + 13;

                for (int i = 0; i < (int)splitNames.size(); ++i) {
                    wstring line = splitNames[i];
                    COLORREF color = FG_COLOR;
                    wstring deltaStr;
                    if (recap && splitLastDelta.size() == splitNames.size())
                        deltaStr = GetDeltaString(i, true);
                    else if (!recap && i < (int)splitSplitTimes.size()
                        && i < (int)bestSplitTimes.size()
                        && bestSplitTimes[i] != duration<double>::max())
                        deltaStr = GetDeltaString(i, false);

                    if (i == currentSplit && timerRunning) {
                        RECT greenBox = {
                            0,
                            y - 2,
                            WINDOW_WIDTH,
                            y + SPLIT_LINE_GAP - 4
                        };
                        DrawRectWithBorder(memDC, greenBox, CURRENT_SPLIT_BG, CURRENT_SPLIT_BORDER, 2);

                        SIZE splitSz;
                        wstring boxText = line;
                        if (!deltaStr.empty()) {
                            boxText += deltaStr;
                        }
                        GetTextExtentPoint32W(memDC, boxText.c_str(), (int)boxText.length(), &splitSz);
                        int splitX = (WINDOW_WIDTH - splitSz.cx) / 2;
                        int centerY = greenBox.top + (greenBox.bottom - greenBox.top - splitSz.cy) / 2;
                        SetTextColor(memDC, color);
                        TextOutW(memDC, splitX, centerY, boxText.c_str(), (int)boxText.length());
                    } else {
                        SIZE splitSz;
                        wstring lineText = line;
                        if (!deltaStr.empty()) {
                            lineText += deltaStr;
                            double delta = recap ? splitLastDelta[i] : (splitSplitTimes[i].count() - bestSplitTimes[i].count());
                            color = GetDeltaColor(delta);
                        }
                        GetTextExtentPoint32W(memDC, lineText.c_str(), (int)lineText.length(), &splitSz);
                        int splitX = (WINDOW_WIDTH - splitSz.cx) / 2;
                        SetTextColor(memDC, color);
                        TextOutW(memDC, splitX, y, lineText.c_str(), (int)lineText.length());
                    }
                    y += SPLIT_LINE_GAP;
                }
                SelectObject(memDC, oldSplitFont);
                DeleteObject(splitFont);
            }

            if (activeTab == TAB_KEYBINDS && !clickThroughEnabled) {
                int numButtons = 4;
                HFONT btnFont = CreateFontW(-15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                            DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
                                            CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Segoe UI");
                HFONT oldBtnFont = (HFONT)SelectObject(memDC, btnFont);
                RECT toggleBtn = GetCenteredButtonRect(0, numButtons);
                RECT splitBtn = GetCenteredButtonRect(1, numButtons);
                RECT cancelBtn = GetCenteredButtonRect(2, numButtons);
                RECT saveBtn  = GetCenteredButtonRect(3, numButtons);

                DrawRoundRectWithBorder(memDC, toggleBtn, BTN_BG, ACCENT_COLOR, 8, 2);
                DrawRoundRectWithBorder(memDC, splitBtn, BTN_BG, ACCENT_COLOR, 8, 2);
                DrawRoundRectWithBorder(memDC, cancelBtn, BTN_BG, ACCENT_COLOR, 8, 2);
                DrawRoundRectWithBorder(memDC, saveBtn, BTN_BG, ACCENT_COLOR, 8, 2);

                SetTextColor(memDC, BTN_TEXT);
                wstring toggleText = rebinding == "toggle" ? L"Press key..." : (L"Toggle: " + GetKeyName(pendingKeybinds["toggle"]));
                wstring splitText  = rebinding == "split" ? L"Press key..." : (L"Split: " + GetKeyName(pendingKeybinds["split"]));
                wstring cancelText = rebinding == "cancel" ? L"Press key..." : (L"Cancel: " + GetKeyName(pendingKeybinds["cancel"]));
                DrawTextW(memDC, toggleText.c_str(), -1, &toggleBtn, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                DrawTextW(memDC, splitText.c_str(), -1, &splitBtn, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                DrawTextW(memDC, cancelText.c_str(), -1, &cancelBtn, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                DrawTextW(memDC, L"Save", -1, &saveBtn, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                SelectObject(memDC, oldBtnFont);
                DeleteObject(btnFont);
            }

            if (activeTab == TAB_EDIT_SPLITS && !clickThroughEnabled) {
                int numButtons = 3;
                HFONT btnFont = CreateFontW(-15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                            DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
                                            CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Segoe UI");
                HFONT oldBtnFont = (HFONT)SelectObject(memDC, btnFont);
                RECT addBtn = GetCenteredButtonRect(0, numButtons);
                RECT removeBtn = GetCenteredButtonRect(1, numButtons);
                RECT resetBestBtn  = GetCenteredButtonRect(2, numButtons);

                DrawRoundRectWithBorder(memDC, addBtn, BTN_BG, ACCENT_COLOR, 8, 2);
                DrawRoundRectWithBorder(memDC, removeBtn, BTN_BG, ACCENT_COLOR, 8, 2);
                DrawRoundRectWithBorder(memDC, resetBestBtn, BTN_BG, ACCENT_COLOR, 8, 2);

                SetTextColor(memDC, BTN_TEXT);
                DrawTextW(memDC, L"+ Add Split", -1, &addBtn, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                DrawTextW(memDC, L"- Remove Last", -1, &removeBtn, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                DrawTextW(memDC, L"Reset Best Times", -1, &resetBestBtn, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
                SelectObject(memDC, oldBtnFont);
                DeleteObject(btnFont);

                int totalHeight = (int)splitNames.size() * (EDITBOX_HEIGHT + EDITBOX_GAP);
                int pageHeight = EDITBOX_SCROLL_AREA_HEIGHT;
                RECT scrollBarArea = { (WINDOW_WIDTH - EDITBOX_WIDTH) / 2 + EDITBOX_WIDTH + 8, GetEditSplitsScrollStartY(), (WINDOW_WIDTH - EDITBOX_WIDTH) / 2 + EDITBOX_WIDTH + 8 + SCROLLBAR_WIDTH, GetEditSplitsScrollStartY() + EDITBOX_SCROLL_AREA_HEIGHT };
                DrawScrollBar(memDC, scrollBarArea, totalHeight, editSplitsScrollPos, pageHeight);

                int yStart = GetEditSplitsScrollStartY();
                for (int i = 0; i < (int)splitNames.size(); ++i) {
                    RECT box = GetCenteredEditBoxRect(i, (int)splitNames.size(), editSplitsScrollPos);
                    if (box.bottom < yStart || box.top > yStart + EDITBOX_SCROLL_AREA_HEIGHT) continue;
                    DrawRoundRectWithBorder(memDC, box, BTN_BG, ACCENT_COLOR, 8, 2);
                }
            }

            BitBlt(hdc, 0, 0, client.right, client.bottom, memDC, 0, 0, SRCCOPY);
            SelectObject(memDC, oldBM);
            DeleteObject(memBM);
            DeleteDC(memDC);

            EndPaint(hwnd, &ps);
            return 0;
        }
        case WM_DESTROY:
            if (timerID) KillTimer(hwnd, timerID);
            if (activeTab == TAB_EDIT_SPLITS) {
                ApplySplitNameEdits();
                SaveSplitsToFile("splits.txt");
                SaveBestSplitsToFile("bestsplits.txt");
            }
            PostQuitMessage(0);
            return 0;
        case WM_GETDLGCODE:
            return HandleWMGetDlgCode(hwnd);
        case WM_CTLCOLOREDIT: {
            HDC hdc = (HDC)wParam;
            SetTextColor(hdc, FG_COLOR);
            SetBkColor(hdc, BTN_BG);
            static HBRUSH hBrush = NULL;
            if (!hBrush) hBrush = CreateSolidBrush(BTN_BG);
            return (INT_PTR)hBrush;
        }
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

typedef BOOL (WINAPI *PFN_SetWindowSubclass)(
    HWND hWnd, SUBCLASSPROC pfnSubclass, UINT_PTR uIdSubclass, DWORD_PTR dwRefData
);
typedef BOOL (WINAPI *PFN_RemoveWindowSubclass)(
    HWND hWnd, SUBCLASSPROC pfnSubclass, UINT_PTR uIdSubclass
);
typedef LRESULT (WINAPI *PFN_DefSubclassProc)(
    HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam
);

HMODULE hComctl = NULL;
PFN_SetWindowSubclass fn_SetWindowSubclass = NULL;
PFN_RemoveWindowSubclass fn_RemoveWindowSubclass = NULL;
PFN_DefSubclassProc fn_DefSubclassProc = NULL;

void EnsureSubclassProcsLoaded()
{
    if (hComctl == NULL) {
        hComctl = LoadLibraryW(L"comctl32.dll");
        if (hComctl) {
            fn_SetWindowSubclass = (PFN_SetWindowSubclass)GetProcAddress(hComctl, "SetWindowSubclass");
            fn_RemoveWindowSubclass = (PFN_RemoveWindowSubclass)GetProcAddress(hComctl, "RemoveWindowSubclass");
            fn_DefSubclassProc = (PFN_DefSubclassProc)GetProcAddress(hComctl, "DefSubclassProc");
        }
    }
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow) {
    INITCOMMONCONTROLSEX icc = { sizeof(icc), ICC_WIN95_CLASSES };
    InitCommonControlsEx(&icc);

    EnsureSubclassProcsLoaded();

    const wchar_t CLASS_NAME[] = L"SplitOverlayApp";
    WNDCLASSW wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hbrBackground = (HBRUSH)GetStockObject(NULL_BRUSH);
    wc.style = CS_HREDRAW | CS_VREDRAW;
    RegisterClassW(&wc);

    int initialHeight = BASE_WINDOW_HEIGHT + (SPLIT_LINE_GAP * max(1, 5)) + SPLIT_BOTTOM_PAD;
    HWND hwnd = CreateWindowExW(
        WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
        CLASS_NAME, L"Split Overlay", WS_POPUP | WS_VISIBLE,
        100, 100, WINDOW_WIDTH, initialHeight,
        NULL, NULL, hInstance, NULL
    );

    g_hwnd = hwnd;
    SetLayeredWindowAttributes(hwnd, 0, 235, LWA_ALPHA);
    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);

    SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
        SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);

    LoadSplitsFromFile("splits.txt");
    LoadBestSplitsFromFile("bestsplits.txt");
    LoadPBFromFile("pbtime.txt");
    LoadKeybinds();
    RegisterKeybinds();
    SetClickThrough(true);
    AdjustWindowHeightForSplits(hwnd);

    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);

        // Subclass newly created edit controls to apply theming
        if (activeTab == TAB_EDIT_SPLITS && !clickThroughEnabled && fn_SetWindowSubclass) {
            for (HWND hEdit : splitEditBoxes) {
                if (IsWindow(hEdit)) {
                    fn_SetWindowSubclass(hEdit, (SUBCLASSPROC)EditSubclassProc, 0, 0);
                }
            }
        }
    }
    for (HWND h : splitEditBoxes) {
        if (IsWindow(h)) DestroyWindow(h);
    }
    splitEditBoxes.clear();

    if (hComctl) FreeLibrary(hComctl);
    return 0;
}

// Patch for missing linker symbols: Use dynamic loading for subclass procs
extern "C" __declspec(dllexport)
BOOL SetWindowSubclass(HWND hWnd, SUBCLASSPROC pfnSubclass, UINT_PTR uIdSubclass, DWORD_PTR dwRefData) {
    EnsureSubclassProcsLoaded();
    if (fn_SetWindowSubclass)
        return fn_SetWindowSubclass(hWnd, pfnSubclass, uIdSubclass, dwRefData);
    return FALSE;
}
extern "C" __declspec(dllexport)
BOOL RemoveWindowSubclass(HWND hWnd, SUBCLASSPROC pfnSubclass, UINT_PTR uIdSubclass) {
    EnsureSubclassProcsLoaded();
    if (fn_RemoveWindowSubclass)
        return fn_RemoveWindowSubclass(hWnd, pfnSubclass, uIdSubclass);
    return FALSE;
}
extern "C" __declspec(dllexport)
LRESULT DefSubclassProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    EnsureSubclassProcsLoaded();
    if (fn_DefSubclassProc)
        return fn_DefSubclassProc(hWnd, uMsg, wParam, lParam);
    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}