Split12x

Split12x is a lightweight Windows overlay timer built for speedrunners. It tracks custom splits, compares against personal bests, and displays a clean, always-on-top overlay that doesn’t get in the way of your game.

✨ Features

Simple, fast, portable executable (Split12x.exe)

On-screen overlay timer that stays above your game

Click-through mode so it won’t block your mouse

Hotkeys for start, split, reset, and pause

Editable splits with persistent save files

Saves best split times and overall PB automatically

🚀 Installation

Download the latest release of Split12x.zip from Releases
.

Extract the .zip anywhere (e.g., Desktop, Games folder).

Run Split12x.exe — no installation required.

⚠️ Antivirus Note:
Because Split12x is a brand-new, unsigned program, Windows Defender or other antivirus software may show a warning. This is a false positive. The full source code is included on GitHub so you can verify and compile it yourself if you prefer.

🎮 Usage

Launch Split12x.exe.

Use the default hotkeys to start/stop/split/reset (shown in the overlay).

Press the interactive mode key to unlock editing.

Edit splits or change hotkeys in the tabs at the top.

Click Save to persist your changes.

🛠️ Building From Source (optional)

If you want to compile yourself:

Requirements:

Windows 10/11

MinGW (g++) or Visual Studio (MSVC)

MinGW build:

g++ -static-libgcc -static-libstdc++ *.cpp -o Split12x.exe -lgdi32 -luser32 -lcomctl32
strip Split12x.exe

📦 Roadmap

Theme customization (colors, fonts, layouts)

Advanced PB and gold split tracking

Import/export split files

In-game auto-splitter support (future)

📜 License

MIT License – free to use, modify, and share.